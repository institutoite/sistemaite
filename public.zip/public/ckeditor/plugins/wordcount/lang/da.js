/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'da', {
    WordCount: 'Ord:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Karakterer:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Karakterer (med HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Afsnit:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Indholdet kan ikke indsættes da det er længere end den tilladte grænse.',
    Selected: 'Markeret: ',
    title: 'Statistik'
});
