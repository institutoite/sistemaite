﻿/*
Mesut ÇAKIR
mesut.cakir@hotmail.com.tr
*/
CKEDITOR.plugins.setLang('wordcount', 'tr', {
    WordCount: 'Kelime:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Karakter:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Karakter (HTML dahil):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Paragraf:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'İstatistik'
});
