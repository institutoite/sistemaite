﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'de', {
    WordCount: 'Wörter:',
    WordCountRemaining: 'Verbleibende Wörter',
    CharCount: 'Zeichen:',
    CharCountRemaining: 'Verbleibende Zeichen',
    CharCountWithHTML: 'Zeichen (inkl. HTML):',
    CharCountWithHTMLRemaining: 'Verbleibende Zeichen (inkl. HTML)',
    Paragraphs: 'Absätze:',
    ParagraphsRemaining: 'Verbleibende Absätze',
    pasteWarning: 'Text kann nicht eingefügt werden. Text ist zu lang.',
    Selected: 'Ausgewählt: ',
    title: 'Statistik'
});
