CKEDITOR.plugins.setLang('wordcount', 'pt', {
    WordCount: 'Palavras:',
    WordCountRemaining: 'Palavras remanescentes',
    CharCount: 'Caracteres:',
    CharCountRemaining: 'Caracteres remanescentes',
    CharCountWithHTML: 'Carateres (incluindo HTML):',
    CharCountWithHTMLRemaining: 'Caracteres (com HTML) remanescentes',
    Paragraphs: 'Parágrafos:',
    ParagraphsRemaining: 'Parágrafos remanescentes',
    pasteWarning: 'O conteúdo não pode ser colado porque ultrapassa o limite permitido',
    Selected: 'Selecionado: ',
    title: 'Estatísticas'
});
