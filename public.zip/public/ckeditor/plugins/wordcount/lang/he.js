﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'he', {
    WordCount: 'מילים:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'תווים:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'תווים (כולל HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'פסקאות:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'לא ניתן להדביק תוכן בשל עודף תווים',
    Selected: 'נבחר: ',
    title: 'סטטיסטיקות'
});