﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ca', {
    WordCount: 'Paraules:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Caràcters:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Caràcters (including HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Paragraphs:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Estadístiques'
});
