﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'nl', {
    WordCount: 'Woorden:',
    WordCountRemaining: 'Resterende woorden',
    CharCount: 'Tekens:',
    CharCountRemaining: 'Resterende tekens',
    CharCountWithHTML: 'Tekens (inclusief HTML):',
    CharCountWithHTMLRemaining: 'Resterende tekens (met HTML)',
    Paragraphs: 'Paragrafen:',
    ParagraphsRemaining: 'Resterende paragrafen',
    pasteWarning: 'De tekst kan niet worden geplakt omdat de limiet is overschreden',
    Selected: 'Geselecteerd: ',
    title: 'Statistieken'
});
