﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("wordcount", "hr", {
    WordCount: "Riječi:",
    WordCountRemaining: 'Words remaining',
    CharCount: "Znakova:",
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: "Znakova (uključujući HTML):",
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: "Paragraphs:",
    ParagraphsRemaining: "Paragraphs remaining",
    pasteWarning: "Content can not be pasted because it is above the allowed limit",
    Selected: "Selected: ",
    title: "Statistika"
});
