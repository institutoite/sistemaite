﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ru', {
    WordCount: 'Слов:',
    WordCountRemaining: 'слов(-а) осталось',
    CharCount: 'Символов:',
    CharCountRemaining: 'символов(-а) осталось',
    CharCountWithHTML: ' (включая HTML-разметку):',
    CharCountWithHTMLRemaining: 'символов(-а) (включая HTML) осталось',
    Paragraphs: 'Параграфов:',
    ParagraphsRemaining: 'параграфов осталось',
    pasteWarning: 'Контент не может быть вставлен, т.к. привышает допустимый лимит',
    Selected: 'Выделено: ',
    title: 'Статистика'
});
