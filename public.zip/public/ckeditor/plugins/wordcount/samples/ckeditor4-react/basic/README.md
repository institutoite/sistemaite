# Basic example

This is a basic showcase of `CKEditor4` component.

Demo is available [here](https://githubbox.com/ckeditor/ckeditor4-react/tree/stable/samples/basic).
