/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
GEO Translation by E404R
*/
CKEDITOR.plugins.setLang('wordcount', 'ka', {
    WordCount: 'სიტყვები:',
    WordCountRemaining: 'დარჩენილი სიტყვები',
    CharCount: 'სიმბოლო:',
    CharCountRemaining: 'დარჩენილი სიმბოლო',
    CharCountWithHTML: 'სიმბოლოები (HTML ით):',
    CharCountWithHTMLRemaining: 'სიმბოლოები (HTML ით) დარჩენილი',
    Paragraphs: 'პარაგრაფი:',
    ParagraphsRemaining: 'დარჩენილი პარაგრაფი',
    pasteWarning: 'ჩასმა შეუძლებელია, რადგან ის აღემატება დასაშვებ ლიმიტს',
    Selected: 'არჩეული: ',
    title: 'სტატისტიკა'
});
